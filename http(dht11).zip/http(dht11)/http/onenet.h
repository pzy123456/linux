#ifndef _ONENET_H_
#define _ONENET_H_

#include "stm32f10x.h"

uint32_t HTTP_PostPkt(char *pkt, char *key, char *devid,char *dsid1, char *dsid2);
#endif
