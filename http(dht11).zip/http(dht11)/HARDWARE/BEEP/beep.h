#ifndef __BEEP_H
#define __BEEP_H

#include "sys.h"

#define beep PBout(8)
void Beep_Config(void);

#endif

