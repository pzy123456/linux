#ifndef _USART_H_
#define _USART_H_

#include "sys.h"

extern  char GA6_Rx_buff[1000];
extern u8 flag;
extern u8 GA6_Rx_count;
void USART_Config(u32 baud);
void USART2_Config(u32 baud);
void UART_SendString(char* s);
void UART2_SendString(char* s);
#endif
