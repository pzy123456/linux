#ifndef __GA6_H
#define __GA6_H

#include "stm32f10x.h"

#define AT_GA6 "AT"
#define CPIN "AT+CPIN?"
#define CREG "AT+CREG?"

extern u8 GA6_AT_MODE;

void GA6_Mode_init(void);
void GA6SendCmd(char* cmd, char* result, int timeOut);
u8 GA6SendATDCmd(char *phone,char *result,u16 timeout);

#endif

